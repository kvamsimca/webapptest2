﻿namespace PhoneBookTestApp
{
    public class Person
    {
        public string name;
        public string phoneNumber;
        public string address;
    }
}