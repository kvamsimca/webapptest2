﻿using System;
using System.Collections.Generic;

namespace PhoneBookTestApp
{
    public class PhoneBook : IPhoneBook
    {
        public List<Person> Contacts = new List<Person>();
        public void addPerson(Person newPerson)
        {
            //throw new NotImplementedException();
            Contacts.Add(newPerson);
        }


        public Person findPerson(string firstName, string lastName)
        {
            // throw new System.NotImplementedException();
           var result = Contacts.Find(x => x.name.ToLower().Contains(firstName.ToLower()) && x.name.ToLower().Contains(lastName.ToLower()));
           return result;
           
        }
    }
}