﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.SQLite;

namespace PhoneBookTestApp
{
    public class DatabaseUtil
    {

        public static void initializeDatabase()
        {
            var dbConnection = new SQLiteConnection("Data Source= MyDatabase.sqlite;Version=3;");
            dbConnection.Open();

            try
            {
                SQLiteCommand command =
                    new SQLiteCommand(
                        "create table PHONEBOOK (NAME varchar(255), PHONENUMBER varchar(255), ADDRESS varchar(255))",
                        dbConnection);
                command.ExecuteNonQuery();

                command =
                    new SQLiteCommand(
                        "INSERT INTO PHONEBOOK (NAME, PHONENUMBER, ADDRESS) VALUES('Chris Johnson','(321) 231-7876', '452 Freeman Drive, Algonac, MI')",
                        dbConnection);
                command.ExecuteNonQuery();

                command =
                    new SQLiteCommand(
                        "INSERT INTO PHONEBOOK (NAME, PHONENUMBER, ADDRESS) VALUES('Dave Williams','(231) 502-1236', '285 Huron St, Port Austin, MI')",
                        dbConnection);
                command.ExecuteNonQuery();



            }
            catch (Exception)
            {
                CleanUp();
            }
            finally
            {
                dbConnection.Close();
            }
        }

        public static SQLiteConnection GetConnection()
        {
            var dbConnection = new SQLiteConnection("Data Source= MyDatabase.sqlite;Version=3;");
            dbConnection.Open();

            return dbConnection;
        }

        public static void CleanUp()
        {
            var dbConnection = new SQLiteConnection("Data Source= MyDatabase.sqlite;Version=3;");
            dbConnection.Open();

            try
            {
                SQLiteCommand command =
                    new SQLiteCommand(
                        "drop table PHONEBOOK",
                        dbConnection);
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        public static int GetContactsCount()
        {
            var dbConnection = new SQLiteConnection("Data Source= MyDatabase.sqlite;Version=3;");
            dbConnection.Open();
            try
            {
                SQLiteCommand command =
         new SQLiteCommand(
                "SELECT COUNT(*) FROM PHONEBOOK",
                dbConnection);

                return Convert.ToInt32(command.ExecuteScalar());
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        public static List<Person> GetAllContacts()
        {
            var dbConnection = new SQLiteConnection("Data Source= MyDatabase.sqlite;Version=3;");
            dbConnection.Open();
            List<Person> contactList = new List<Person>();
            try
            {
                SQLiteCommand command =
         new SQLiteCommand(
                "SELECT * FROM PHONEBOOK",
                dbConnection);

                using (SQLiteDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Person p = new Person { name = reader["NAME"].ToString(), address = reader["ADDRESS"].ToString(), phoneNumber = reader["PHONENUMBER"].ToString() };
                        contactList.Add(p);
                    }
                }
                return contactList;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                dbConnection.Close();
            }
        }
        public static void InsertPerson(Person person)
        {
            var dbConnection = new SQLiteConnection("Data Source= MyDatabase.sqlite;Version=3;");
            dbConnection.Open();
            try
            {
                string insertQuery = String.Format("INSERT INTO PHONEBOOK (NAME, PHONENUMBER, ADDRESS) VALUES('{0}','{1}','{2}')", person.name, person.phoneNumber, person.address);
                SQLiteCommand command =
                  new SQLiteCommand(insertQuery, dbConnection);
                command.ExecuteNonQuery();


            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                dbConnection.Close();
            }
        }
    }
}