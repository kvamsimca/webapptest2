﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneBookTestApp
{
    class Program
    {
        private PhoneBook phonebook = new PhoneBook();
        static void Main(string[] args)
        {
            try
            {
                 
                DatabaseUtil.initializeDatabase();
                /* TODO: create person objects and put them in the PhoneBook and database
                * John Smith, (248) 123-4567, 1234 Sand Hill Dr, Royal Oak, MI
                * Cynthia Smith, (824) 128-8758, 875 Main St, Ann Arbor, MI
                */

                // TODO: print the phone book out to System.out
                // TODO: find Cynthia Smith and print out just her entry
                // TODO: insert the new person objects into the database

                PhoneBook pb = new PhoneBook();
                Person p1 = new Person { name = "John Smith", address = "1234 and Hill Dr, Royal Oak, MI", phoneNumber = "(248) 123-4567" };
                Person p2 = new Person { name = "Cynthia Smith", address = "875 Main St, Ann Arbor, MI", phoneNumber = "(824) 128-8758" };
                pb.addPerson(p1);
                pb.addPerson(p2);

                Console.WriteLine("PhoneBook:");
                foreach (var contact in pb.Contacts)
                {
                    Console.WriteLine(contact.name + '/' + contact.address + "/" + contact.phoneNumber);
                }
                Console.WriteLine();
                var result = pb.findPerson("cynthia", "smith");
                Console.WriteLine();

                Console.WriteLine("Finding and Printing Cynthia's Contact:");
                if (result != null)
                    Console.WriteLine(result.name + '/' + result.address + "/" + result.phoneNumber);
               
                Console.WriteLine();

                Console.WriteLine("Number of Persons in Phone Book: " + DatabaseUtil.GetContactsCount());
                
               //Insert Persons to PhoneBook
                foreach (var contact in pb.Contacts)
                {
                    DatabaseUtil.InsertPerson(contact);
                }
               
                Console.WriteLine("Number of Persons in Phone Book After Inserting John and Cynthia : " + DatabaseUtil.GetContactsCount());
                Console.WriteLine();
                Console.WriteLine("Contacts from PhoneBook:");
                foreach (var contact in DatabaseUtil.GetAllContacts())
                {
                    Console.WriteLine(contact.name + '/' + contact.address + "/" + contact.phoneNumber);
                }
                Console.WriteLine();

            }
            finally
            {
                DatabaseUtil.CleanUp();
            }
        }
    }
}
